var searchData=
[
  ['uartprint_0',['Uartprint',['../console_8h.html#a015a11129ea35ac328bf47731fa7dee5',1,'Uartprint(char *s, int a):&#160;console.c'],['../console_8c.html#a015a11129ea35ac328bf47731fa7dee5',1,'Uartprint(char *s, int a):&#160;console.c']]],
  ['uartreceive_1',['Uartreceive',['../console_8c.html#a6c7cc47fc8ea8e38e8af893e0b2c0e9a',1,'console.c']]],
  ['uartrecieve_2',['Uartrecieve',['../console_8h.html#ab701f13cd1479c88b7abd11c75f6e4a7',1,'console.h']]],
  ['usagefault_5fhandler_3',['UsageFault_Handler',['../stm32g4xx__it_8h.html#a1d98923de2ed6b7309b66f9ba2971647',1,'UsageFault_Handler(void):&#160;stm32g4xx_it.c'],['../stm32g4xx__it_8c.html#a1d98923de2ed6b7309b66f9ba2971647',1,'UsageFault_Handler(void):&#160;stm32g4xx_it.c']]],
  ['usart1_5firqhandler_4',['USART1_IRQHandler',['../stm32g4xx__it_8h.html#a7139cd4baabbbcbab0c1fe6d7d4ae1cc',1,'USART1_IRQHandler(void):&#160;stm32g4xx_it.c'],['../stm32g4xx__it_8c.html#a7139cd4baabbbcbab0c1fe6d7d4ae1cc',1,'USART1_IRQHandler(void):&#160;stm32g4xx_it.c']]],
  ['usart2_5firqhandler_5',['USART2_IRQHandler',['../stm32g4xx__it_8h.html#a0ca6fd0e6f77921dd1123539857ba0a8',1,'USART2_IRQHandler(void):&#160;stm32g4xx_it.c'],['../stm32g4xx__it_8c.html#a0ca6fd0e6f77921dd1123539857ba0a8',1,'USART2_IRQHandler(void):&#160;stm32g4xx_it.c']]]
];
