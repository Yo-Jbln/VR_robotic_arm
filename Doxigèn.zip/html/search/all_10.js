var searchData=
[
  ['vdd_5fvalue_0',['VDD_VALUE',['../stm32g4xx__hal__conf_8h.html#aae550dad9f96d52cfce5e539adadbbb4',1,'stm32g4xx_hal_conf.h']]],
  ['vitconfig_1',['VitConfig',['../motor_8h.html#aca821f01d77d2f1d45a071fa077cd7ad',1,'VitConfig(int M, int v):&#160;motor.c'],['../motor_8c.html#aca821f01d77d2f1d45a071fa077cd7ad',1,'VitConfig(int M, int v):&#160;motor.c']]],
  ['vitesse_2',['vitesse',['../struct_motor_state.html#a4b512d0a6dcc3c7d7e6dd9a7714852c4',1,'MotorState']]]
];
