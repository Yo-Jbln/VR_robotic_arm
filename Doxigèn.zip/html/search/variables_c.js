var searchData=
[
  ['uart_5frx_5fbuffer_0',['uart_rx_buffer',['../console_8h.html#a8cf6f55cf4735df9d67b1bb52f6f861b',1,'uart_rx_buffer():&#160;console.c'],['../console_8c.html#a8cf6f55cf4735df9d67b1bb52f6f861b',1,'uart_rx_buffer():&#160;console.c']]],
  ['uart_5ftx_5fbuffer_1',['uart_tx_buffer',['../console_8h.html#aa93aa9d1693aa2349621dafaa4414beb',1,'uart_tx_buffer():&#160;console.c'],['../motor_8h.html#af97b0d97676ba082025edcb312a905a3',1,'uart_tx_buffer():&#160;console.c'],['../console_8c.html#aa93aa9d1693aa2349621dafaa4414beb',1,'uart_tx_buffer():&#160;console.c']]]
];
