var searchData=
[
  ['vitconfig_0',['VitConfig',['../motor_8h.html#aca821f01d77d2f1d45a071fa077cd7ad',1,'VitConfig(int M, int v):&#160;motor.c'],['../motor_8c.html#aca821f01d77d2f1d45a071fa077cd7ad',1,'VitConfig(int M, int v):&#160;motor.c']]]
];
