var searchData=
[
  ['backspace_0',['backspace',['../console_8c.html#a6fe4ce0fed1f649532f07904b5b47e0a',1,'console.c']]]
];
