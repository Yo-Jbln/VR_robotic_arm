var searchData=
[
  ['environ_0',['environ',['../syscalls_8c.html#aa006daaf11f1e2e45a6ababaf463212b',1,'syscalls.c']]],
  ['esp_5frx_5fbuffer_1',['esp_rx_buffer',['../main_8c.html#a6a73641601d165a9a828fffe922a546d',1,'main.c']]],
  ['esp_5ftx_5fbuffer_2',['esp_tx_buffer',['../main_8c.html#a0e55b76283bc8af9db00a91adef5dd08',1,'main.c']]]
];
